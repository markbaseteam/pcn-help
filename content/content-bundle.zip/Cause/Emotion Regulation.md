![[Pasted image 20230607083919.png]]
Negative emotions primarily cause procrastination by deterring engagement with necessary tasks, especially since people generally want to postpone negative emotional states.


As a students, its possible to yield following emotion regulation problem that would cause procrastination:

- #### avoid negative emotions
	- people postpone aversive tasks, to avoid negative emotions that are associated with those tasks
	
- #### Indulge into the positive emotions
	- people postpone tasks to avoid the absence of positive emotions (if a task isn’t exciting), or to create, increase, or prolong positive emotions (when a more appealing alternative is available, such as digital entertainment).



# Techniques

[[Give yourself permission to make mistakes]]
[[Form implementation intentions]]
[[Increase your energy]]
[[Increase your motivation]]
[[Immediately complete small tasks]]
