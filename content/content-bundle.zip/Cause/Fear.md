![[Pasted image 20230607083630.png]]

Acommon reason for procrastination is fear, meaning that people procrastinate because they’re afraid of something, such as failing or being criticized. 


*As a student, you may face the following types of fears commonly:

- #### Fear of failure
	- For example, this fear can play a role when a student worries that they will fail a test, so they avoid studying for the test to avoid thinking about it. Fear of failure is the most common type of fear that’s researched and mentioned as a cause of procrastination.
	
- #### Fear of negative evaluation
	- For example, this fear can play a role when someone worries that they will get judgmental feedback or harsh criticism on their performance during a public presentation, so they delay preparing for it to avoid thinking about it. Note that this fear has to do with how someone’s performance will be evaluated by others, rather than about the actual quality of the performance. This means, for example, that someone might worry that they will receive negative feedback even if they’re likely to do well, because they lack confidence or have low self-esteem.
	
- #### Fear of inadequacy. 
	- For example, this fear can play a role when someone worries that if they do poorly on an assignment, then that will mean that they’re not skilled enough to ever be successful. Conceptually, this is generally about failing on a personal level, meaning that not only is our performance not good enough, but also we’re not good enough.
	
- #### Fear of the unknown. 
	- For example, this fear can play a role when someone worries about going to practice a new sport or hobby, when they don’t exactly know what it will involve.



# Techniques
[[Develop self efficacy]]
[[Give yourself permission to make mistakes]]
[[Make it easier to decide]]
[[Make it easier to take action]]

