![[Pasted image 20230607083443.png]]

Self-control is always crucial in many areas of life. Therefore, self-control failure is the source of many of the difficulties people face in their lives and also at the center of several problems, especially students population. 


Low self-control is associated with increased procrastination in the following way:

- #### Poor self control made people against their better judgment through weakness of will
	- An example of that for high school students that results in procrastination could be playing video games for an excessive amount of time or checking social media when there is a ergent task needs to be finished.


# Techniques
[[Develop self efficacy]]
[[Immediately complete small tasks]]
[[Increase your energy]]
[[Increase your motivation]]
[[Set deadlines]]
[[Time management techniques]]
