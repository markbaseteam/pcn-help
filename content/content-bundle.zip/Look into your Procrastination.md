
First It's important to ***identify*** what has caused you to procrastinate or delay unnecessarily on certain tasks.

There are 3 major causes are determined through a sample of (high school) students to help you find yours

### Potencial cause:
- [[Emotion Regulation]]
- [[Fear]]
- [[Self Control]]


![[Pasted image 20230605125557.png]]