![[Pasted image 20230607085503.png]]

Self-efficacy is a person’s objective belief in their ability to perform the actions needed to achieve their goals. 

A high self efficacy means that a student would have steadfast trust and confidence in one's caplability in completing the task, therefore being reluctent to procrastinate.

**Here are few ways that can help you build a higher self efficacy**:
- #### Achieve easy initial successes [[[Immediately complete small tasks|similar technique]]
	- For example, if you’re faced with a major project, try to deal with a few initial small parts of it that you can easily complete

- #### Reflect on your successes [[Increase your energy|similar technique]]
	- For example, if you’re faced with a difficult task, think about times in the past when you were able to successfully handle similar tasks

- #### **Reflect on the successes of others
	- For example, if you’re faced with a challenge, think about how a friend who is similar to you was able to handle that challenge successfully, and realize that this means that you will likely also be able to handle it

- #### **Imagine yourself succeeding 
	- For example, if you need to give a speech, imagine yourself doing really well and getting applause from the audience