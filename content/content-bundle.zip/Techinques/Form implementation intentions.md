![[Pasted image 20230607085336.png]]

Implementation intentions are concrete plans regarding when, where, and how you’ll pursue your goals. They primarily involve establishing if-then rules (i.e., “If X happens, then I’ll do Y”), which describe how you’ll overcome obstacles and temptations using goal-directed behavior (to support your goal intentions). Good rules are often ones that you can apply automatically (i.e., with minimal deliberation), which increases the likelihood that you’ll use them.
 
For example, if you need to study without being distracted, you can decide that you’ll do so at the library while wearing noise-blocking headphones. You can also decide that if someone comes over and starts trying to talk, you’ll respond by saying “sorry, we can chat later, but I really have to study right now”.
