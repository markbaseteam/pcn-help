![[Pasted image 20230607084844.png]]

It's reasonable to think before doing, but it's more important to take to action without absolute right direction than never start it. Start with doing something instead think too much till you'll never make your firsr step.

If you’re writing a essay, accept that your work won’t be perfect, especially when it comes to the first draft, and remember that you can always revise your writing afterward. 