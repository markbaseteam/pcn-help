![[Pasted image 20230607084642.png]]

It can sometimes be beneficial to complete small tasks as soon as you encounter them, for example because the motivation for them is still fresh, because scheduling them will require more work than just doing them, or because this prevents them from piling up into something that feels overwhelming.

You can decide what’s considered a “small” task, based on what works well for you. A popular definition is any task that takes less than 2 minutes to complete (this is known as the _2-minute rule_, and is distinct from the similarly named rule about committing to a tiny first step).  