![[Pasted image 20230607084616.png]]

- Listen to energizing music.

- Take a short break (e.g., go outside to breathe some fresh air).

- Take a long break to ensure you get sufficient rest.

- Improve your lifestyle (e.g., by eating better, exercising, and getting enough sleep).

- Minimize unnecessary energy drains (e.g., by setting heuristics regarding the default clothes you’ll wear each day, to reduce the number of unimportant but taxing decisions you make).