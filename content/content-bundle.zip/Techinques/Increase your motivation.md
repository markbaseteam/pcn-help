![[Pasted image 20230607084455.png]]

- #### Gamify your behavior. This involves incorporating elements from games, like competition with others and the accumulation of points, into other types of activities. 
	- For example, if your New Year’s resolution is to have no zero days (on which you make no progress toward your goals), then you can give yourself a point for each day you achieve this, and get a reward after every 10 points.

- #### Create streaks. Streaks are chains of days in a row on which you achieve your goals. You should track them in a way that’s motivating and convenient. 
	- For example, you can use a dedicated app, or the Seinfeld strategy (by marking a big X in a calendar on each day you achieve your goals).

- #### Reward your accomplishments. 
	- For example, you can take a short break to watch TV for every chapter that you read in preparation for a test. You can also find ways to make your progress feel more rewarding, like going over your to-do list at the end of each day, to feel good about how much you got done.

- #### Set immediate outcomes. 
	- For example, you can eat a piece of candy as reward for every task that you complete while working on a project. That’s because the closer in time outcomes are, the more you care about them (both positive outcomes for acting on time and negative ones for procrastinating).

- #### Visualize your future self. 
	- For example, if you’re procrastinating on an assignment because its grade will only come in a few weeks, you can imagine your future self getting that grade. This mental time travel (or episodic future thinking) can improve the connection between your present and future selves (i.e., your temporal self-continuity), to make you care more about your future self, the future consequences of your actions, and the perceived value of future outcomes. 