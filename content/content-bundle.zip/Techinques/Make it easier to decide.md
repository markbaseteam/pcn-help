![[Pasted image 20230607084404.png]]

-   Improve your decision-making environment (removing distractions).
    
-   Rely on your intuition ([[Make it easier to take action]])
    
-   Aim to make decisions that are good enough ([[Give yourself permission to make mistakes]])
    
-   Use a structured approach to decision-making
    
-   Eliminate weak options from your available choices
    
-   Create decision pairs, by comparing only two options at a time rather than multiple ones
    
-   Get feedback from someone else, and potentially ask them to choose for you
    
-   Use a random tool
    
-   Doing this is especially important if you procrastinate primarily due to indecisiveness
