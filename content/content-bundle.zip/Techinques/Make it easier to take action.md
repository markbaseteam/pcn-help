![[Pasted image 20230607084306.png]]

For example, if you’ll need to work on a work later, you can leave it open on your computer or lay the essential materials on the desk, so it will be immediately available when you start working.

Essentially, you should make it as easy as possible to start and keep doing what you should be doing, primarily by removing any *friction* that might hinder you.