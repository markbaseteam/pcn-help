![[Pasted image 20230607084142.png]]

You may already have a lot deadlines in the school as a student, but you can still set deadlines for your own activities. 
For example, if you want to read a book but keep postponing it for a long time, you can set a deadline to finish the a quarter of the book within 2 weeks. 

#### Deadlines should be:
-   _Appropriate_, so they shouldn’t give you too much or too little time.
-   _Concrete_, so they should specify an exact point in time.
-   _Meaningful_, so they should involve an effective incentive for abiding by them (e.g., someone who will hold you accountable).




