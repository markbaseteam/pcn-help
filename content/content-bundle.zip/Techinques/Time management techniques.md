![[Pasted image 20230607084030.png]]

- #### Use a to-do list
	- For example, you can write down a list of upcoming tasks in a notebook or an [app](https://solvingprocrastination.com/procrastination-apps/)              (a quick extension example: [momentum](https://momentumdash.com))
	    Note that write something down at first time is important as it would force yourself to make the [[Give yourself permission to make mistakes|first step]].
	
- #### Prioritize tasks
	- For example, you can use the _Ivy Lee Method_, by writing down—at the end of each day—six tasks you want to complete tomorrow, ranked in order of importance. Similarly, you can use an _Eisenhower matrix_, by determining how important and how urgent your tasks are, and then using that to decide what to work on.
	
- #### Set reminders
	- For example, you can put a sticky note next to your laptop if there’s something you need to do tomorrow, or you can use an app to send you a notification when there’s a task that you need to complete soon.
	
- #### Alternate consistently between work and rest 
	- For example, you can use the Pomodoro technique, by working on your tasks for 25-minute long stretches, with 5-minute breaks in between, while taking a longer 30-minute break after every 4 work sets.
